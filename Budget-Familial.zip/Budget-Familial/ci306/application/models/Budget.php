<?php

class Budget extends CI_Model {



public function benefice_total($i){
		$liste=$this->db->query("SELECT* FROM Benef where idpers=".$i."");
	    return $liste->row_array();	
	}
public function depense_commun_total($m,$n){
		$liste=$this->db->query("SELECT* FROM Depensecommun where nature='$n' and mois='$m'");
	    return $liste->row_array();
		
	}
public function benefice_reste(){
		$total=benefice_total()-depense_commun_total();
		return $total;
	}
public function budget_commun(){
		$total=benefice_reste();
		$budget=($total*20)/100;
		return $budget;
	}
public function budget_perso(){
		$total=benefice_reste();
		$budget=($total*80)/100;
		return $budget;
	}
public function new_budget_commun(){
		$total=benefice_reste();
		$select="SELECT* FROM Personne WHERE type=enfant";
		$liste=$db->prepare($select);
		$liste->execute();
		$nombre=0;
		while ($l=$liste->fetch(PDO::FETCH_OBJ)) {
			$total=$total-$l->argent_perso;
		}
		return $total;
	}
public function nombre_enfant(){
		$select="SELECT* FROM Personne WHERE type=enfant";
		$liste=$db->prepare($select);
		$liste->execute();
		$nombre=0;
		while ($l=$liste->fetch(PDO::FETCH_OBJ)) {
			$nombre=$nombre+1;
		}
		return $nombre;
	}
public function budget_enfant($budget_perso,$nombre_enfant){
		if ($nombre_enfant==0) {
			$budget=0;
			return $budget;
		}
		if ($nombre_enfant==1) {
			$budget=($budget_perso*15)/100;
			return $budget;
		}
		if ($nombre_enfant>=2||$nombre_enfant<=4) {
			$budget=($budget_perso*30)/100;
			$budget=$budget/$nombre_enfant;
			return $budget;
		}
		if ($nombre_enfant>=5) {
			$budget=($budget_perso*45)/100;
			$budget=$budget/$nombre_enfant;
			return $budget;
		}
		return 0;
	}
public function budget_adulte(){
		$select="SELECT* FROM Personne";
		$liste=$db->prepare($select);
		$liste->execute();
		$nombre=0;
		while ($l=$liste->fetch(PDO::FETCH_OBJ)) {
			$nombre=$nombre+1;
		}
		$adulte=$nombre-nombre_enfant();
		$budget=budget_perso()-budget_enfant();
		$budget=$budget/$adulte;
		return $budget;
	}
public function insert_argent_perso($nom,$montant){
		$select="SELECT* FROM Personne";
		$liste=$db->prepare($select);
		$liste->execute();
		while ($l=$liste->fetch(PDO::FETCH_OBJ)) {
			if ($l->nom==$nom) {
				$connexion->exec("UPDATE Personne WHERE id_prs='".$l->id_prs."' SET argent_perso='".$montant."'");
			}
		}
}
public function insert_depense($date,$montant,$nature){
		$new;
		$select="SELECT* FROM Personne";
		$liste=$db->prepare($select);
		$liste->execute();
		while ($l=$liste->fetch(PDO::FETCH_OBJ)) {
			if ($num==$l->id_prs) {
				$new=$l->argent_perso-$montant;
				if ($new<0) {
					return "Tsy ampy vola";
				}
			}
		}
		$connexion->exec("INSERT INTO Depense_indiv(id_prs,date,montant,nature) VALUES (".$num.",'".$date."','".$montant."','".$nature."')");
	}



public function insert_benefice($montant){
		$select="SELECT* FROM Benefice";
		$liste=$db->prepare($select);
		$liste->execute();
		while ($l=$liste->fetch(PDO::FETCH_OBJ)) {
			if ($num==$l->id_prs) {
				$montant=$montant+$l->imprevu;
			}
		}
		$connexion->exec("UPDATE Benefice WHERE id_prs=".$num." SET imprevu='".$montant."'");
	}


} ?>