<?php

class Olona extends CI_Model {

public function login($n,$m){
				$liste=$this->db->query("SELECT* FROM Personne where nom='$n' and mdp='$m' ");
	    return $liste->row_array();	
	}

	public function prs($id){
		$liste=$this->db->query("SELECT* FROM Personne where id='$id'");
return $liste->row_array();	
}
public function changer($nom){
		$liste=$this->db->query("SELECT* FROM Personne where nom='$nom'");
return $liste->row_array();	
}

public function ajoutDepense($date,$montant,$nature)
{
	$liste=$this->db->exec("UPDATE DepenseIndiv('dateDepense','montant','nature') SET('$date','$montant','$nature') ");
	return $liste->row_array();	

}	


}	
?>