<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fonction extends CI_Controller {
	
 public function loginUser()
	{
		$this->load->model('Olona');
        $tabl=$this->Olona->login($this->input->post('nom'),$this->input->post('mdp'));
		if ($tabl==null) {
			echo "Nom d'utilisater ou Mot de passe incorrect,veulliez réessayer";
			$this->load->view('welcome_message');
			return;
		}
		
		if ($tabl['age']<12) {
			echo "Vous n'avez pas l'âge nécessaire pour vous connecter";
			$this->load->view('welcome_message');
			return;
		}

		if ($tabl['type']=='adulte') {
			$this->load->view('acceuilAdmin');
			return;
		}

		if ($tabl['age']>12) {
		
			$this->load->view('acceuil');
		}

	}	
	public function DepensePerso()
	{
		$this->load->model('Olona');
        $tabl=$this->Olona->getID($this->input->post('nom'));
	}

	public function ajout()
	{
		$this->load->model('Olona');
	}

	public function miditra(){
		$this->load->model('Budget');
		$liste=$this->Budget->benefice_total(3);
		$liste1=$this->Budget->benefice_total(4);
		$total=$liste['salaire'];
		$total=$total+$liste1['salaire'];
		echo "Benefice Total =".$total;?></br><p>Depense necessaire: </p><?php 
		$liste2=$this->Budget->depense_commun_total("Juillet","jirama");
		$liste3=$this->Budget->depense_commun_total("Juillet","fete");
		echo $liste2['nature']."=".$liste2['montant'];?></br><?php 
		echo $liste3['nature']."=".$liste3['montant'];?></br><?php 
		$commun=$liste3['montant']+$liste2['montant'];
		$reste=$total-$commun;
		$budget_com=($reste*20)/100;
		$budget_mizara=($reste*80)/100;
		?></br><?php echo "Budget activite commun=".$budget_com;?></br><?php 
		$this->load->model('Olona');
		$nombre=0;
	for ($i=1; $i <5 ; $i++) { 
		$tabl=$this->Olona->prs($i);
		if ($tabl['age']<18) {
			$nombre=$nombre+1;
		}
	}
		$this->load->model('Budget');
		$budget_enfant=$this->Budget->budget_enfant($budget_mizara,$nombre);
		$budget_adulte=($budget_mizara-$budget_enfant)/2;
		echo "Il y a ".$nombre." enfant avec un montant de ".$budget_enfant."Ar chacun";?></br><?php
		echo "Il y a ".$nombre." adulte avec un montant de ".$budget_adulte."Ar chacun";?></br><?php
	$this->load->view('acceuilAdmin');
 }
 public function update()
{
	$this->load->model('Budget');
		$liste=$this->Budget->benefice_total(3);
		$liste1=$this->Budget->benefice_total(4);
		$total=$liste['salaire'];
		$total=$total+$liste1['salaire'];
		$liste2=$this->Budget->depense_commun_total("Juillet","jirama");
		$liste3=$this->Budget->depense_commun_total("Juillet","fete");
		$commun=$liste3['montant']+$liste2['montant'];
		$reste=$total-$commun;
		$budget_com=($reste*20)/100;
		$budget_mizara=($reste*80)/100;
		$this->load->model('Olona');
		$nombre=0;
	for ($i=1; $i <5 ; $i++) { 
		$tabl=$this->Olona->prs($i);
		if ($tabl['age']<18) {
			$nombre=$nombre+1;
		}
	}
		$this->load->model('Budget');
		$budget_enfant=$this->Budget->budget_enfant($budget_mizara,$nombre);
		$budget_adulte=($budget_mizara-$budget_enfant)/2;
		$this->load->model('Olona');
		   $tabl=$this->Olona->changer($this->input->post('nom'));
	   if($this->input->post('plus')<0){
		echo "L'argent de ".$tabl['nom']." diminue de ".$this->input->post('plus')."";?></br><?php
	   }
	   if($this->input->post('plus')>0){
		echo "L'argent de ".$tabl['nom']." augmente de ".$this->input->post('plus')."";?></br><?php
	   }
	$this->load->view('acceuil');

}

public function acceuil()
{
	$this->load->view('acceuil');

}
}