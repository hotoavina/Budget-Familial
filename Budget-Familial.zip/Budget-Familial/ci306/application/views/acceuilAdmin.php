<!DOCTYPE html>
<html>
<head>
	<title>
	</title>
	<meta charset="utf-8">
	
</head>
<body>
	<form action="http://localhost/ci306/index.php/Fonction/miditra" method="post">
        <input type="submit" name="Info" value="Info" ></br>
	</form>
</br>
	<form action="http://localhost/ci306/index.php/Fonction/update" method="post">
		<p>Nom</p><input type="text" name="nom" ></br>
		<p>Montant</p><input type="text" name="plus" ></br>
		<input type="submit" name="OK" value="OK" ></br>
	</form>
	<a href="http://localhost/ci306/index.php/Fonction/acceuil"></a>
</body>
</html>