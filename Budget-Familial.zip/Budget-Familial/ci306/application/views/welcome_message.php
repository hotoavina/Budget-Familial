<?php 

	$this->load->helper('url');
	
    $liste=$this->db->query("SELECT nom FROM Personne");

?>
<!DOCTYPE html>
<html lang="en" style="padding: 0px;margin: -1px;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Unti</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/ionicons.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/Login-Form-Dark.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/styles.css'); ?>">
</head>

<body>
    <section class="login-dark">
        <form method="post" action="http://localhost/ci306/index.php/Fonction/loginUser">
            <h2 class="visually-hidden">Login Form</h2>
            <div class="illustration"><i class="icon ion-ios-locked-outline"></i></div>
            <div class="mb-3"><input class="form-control" type="text" name="nom" placeholder="Claude" values="Claude"></div>
            <div class="mb-3"><input class="form-control" type="text" name="mdp" placeholder="1234" values="1234"></div>
            <div class="mb-3"><button class="btn btn-primary d-block w-100" type="submit">Log In</button></div>
        </form>
       <p>Andriamahefa Fitia Faniry ETU001375</p> 
       <p>Haritsima Mihamina Ho-Toavina ETU001404</p>
    </section>
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
</body>

</html>