<!DOCTYPE html>
<html>
<head>
	<title>
	</title>
	<meta charset="utf-8">
	
</head>
<body>
	<form action="http://localhost/ci306/index.php/Fonction/acceuil" method="post">
		<input class="form-control" type="date" name="date" placeholder="Date de la depense">
		<input class="form-control" type="text" name="montant" placeholder="Montant">
		<input class="form-control" type="text" name="nature" placeholder="Nature">
		<input type="submit" name="ajout" value="Ajouter depense"></br>
	</form>
	<form action="http://localhost/ci306/index.php/Fonction/acceuil" method="post">
		<input class="form-control" type="date" name="date" placeholder="Date du gain">
		<input class="form-control" type="text" name="montant" placeholder="Montant">
		<input class="form-control" type="text" name="nature" placeholder="Nature">
		<input type="submit" name="dfg" value="Ajouter benefice" ></br>
	</form>
</body>
</html>